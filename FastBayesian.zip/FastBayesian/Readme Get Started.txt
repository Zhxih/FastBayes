Summary：
    - The "CodeSumbit" file includes codes and data for "Fast Bayesian Inference on Spectral Analysisof Multivariate Stationary Time Series" by Zhixiong Hu and Raquel Prado.
    - The codes are written in Python 3.7.0 (suggested version >= 3.0).    
    - Author: Zhixiong Hu


Structure of the files:
    - "SimulationStudyDemo.py" and "DataAnalysisDemo.py" are runbooks to show how to use our approach to reproduce part of the results in the paper.
    - "Model" file has the model class "SpecVI.py" that defines the framework.
    - "Data" file includes example data and processing scripts.

Quick guide:
To run the runbooks, two things needs to be done:
    1) Set "CodeSubmit" as the work directory.
    2) Install relevant packages:
        - pip install Tensorflow (>= 2.1) 
	  (The default version is for cpu. GPU version requires extra sophisticated GPU setup, which is beyond the workload of this demo.)
	- pip install --upgrade tensorflow-probability (>= 0.9)
	- pip install pandas (>= 1.0.3)
	- pip install numpy (>= 1.19.5)
	- (pip install scipy if necessary, this package should be included in python by default)