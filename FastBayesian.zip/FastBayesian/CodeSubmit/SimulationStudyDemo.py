# -*- coding: utf-8 -*-
"""
Multivariate Spectral Analysis Simulation Study Demo

@author: Zhixiong Hu
"""
import os
# os.chdir('CodeSubmit')
# set current work directory to be "CodeSubmit"

import numpy as np
import matplotlib.pyplot as plt
from scipy import signal

import tensorflow as tf
import tensorflow_probability as tfp
tfd = tfp.distributions
tfb = tfp.bijectors
from Model import SpecVI # model class
from Data import VarSim # to simulate data

#########################################################
## Simulation Study 1: Bivariate Analysis ###############

## simulate data ##################################
n = 1024
phi_1 = np.diag((0.5, -0.3))
phi_2 = np.diag((0, -0.5))
# scene = 1: correlated; scene = 0: uncorrelated
scene = 1
s_cov = [0.9 if scene == 1 else 0.0][0]
Sigma = np.array(((1, s_cov), (s_cov, 1)))
x_0 = np.array((0, 0))
x_1 = np.array((0, 0))
x = np.empty((n+100, 2))
x[:] = np.NaN
x[0, ] = x_0
x[1, ] = x_1
np.random.seed(12345)
for i in np.arange(2, x.shape[0]):  # 2,3,...,x.shape[0]-1
    x[i,] = np.matmul(phi_1, x[i-1,]) + np.matmul(phi_2, x[i-2,]) + \
            np.random.multivariate_normal(np.repeat(0, 2), Sigma) # can also specify size
x = x[100:] # drop the first 100
# true spectra
def f_11(nu):
    # nu: np.array
    return (1.25 - np.cos(2*np.pi*nu))**-1
def f_22(nu):
    # nu: np.array
    rlt = 1.34 + 0.9 * np.cos(2*np.pi*nu) + np.cos(4*np.pi*nu)
    return rlt**(-1)
f_true = [f_11, f_22]


## Model run #######################################
Spec = SpecVI.SpecVI(x)
'''
If data_n-by_p_dim is large (e.g., for n>1000 & p>100) to throw OOM warning, 
change "sparse_op = True" to save memory by using sparse matrix operations. 

When n and p is not too large, "sparse_op = False" (default) is recommended, 
which works more light and faster!  
'''
# result_list = [spectral matrix estimates, model objects,]
result_list = Spec.runModel(N_delta=30, N_theta=30, lr_map=5e-3, ntrain_map=5e3, sparse_op=False)
spec_mat = result_list[0]
freq = result_list[1].freq

## Result Visualization ###########################
# Reproduce Figure 1 (top) and Figure 2 (if set scene = 0)
fig, ax = plt.subplots(1,3, figsize = (11, 5))
for ii in range(x.shape[1]):
    f, Pxx_den0 = signal.periodogram(x[:,ii], fs=1)
    f = f[1:]
    Pxx_den0 = Pxx_den0[1:] / 2 
    f_CI = np.abs(spec_mat[...,ii,ii])
    
    ax[ii].plot(f, np.log(Pxx_den0), marker = '.', markersize=2, linestyle = 'None')
    ax[ii].plot(f, np.log(f_true[ii](f)), linewidth=3, linestyle='--', color = 'red', label = 'True')
    ax[ii].fill_between(freq, np.squeeze(np.log(f_CI[0])), np.squeeze(np.log(f_CI[2])), 
                    color = 'darkgrey', alpha = 1, label = '95% CI')
    ax[ii].tick_params(labelsize=15)
    ax[ii].set_xlabel(r'$\nu$', fontsize=20, labelpad=10)
    #ax.set_ylabel(r'$\log$ spectral density', fontsize=20)
    ax[ii].set_title(r'$\log f_{%s}$'%(ii+1), pad=20, fontsize=20)
    ax[ii].set_xlim([0, 0.5])
    ax[ii].set_ylim([-12.5, 6.0])
    ax[ii].grid(True)
    if ii == 0:
        ax[ii].legend(fontsize='large', frameon=False)
f_CI = np.square(spec_mat[...,0,1]) / np.abs(spec_mat[...,0,0]) / np.abs(spec_mat[...,1,1])
if scene == 1:
    ax[2].axhline(y=0.8, linewidth=3, linestyle='-.', color = 'red', label = 'Truth') 
else:
    ax[2].axhline(y=0.005, linewidth=3, linestyle='-.', color = 'red', label = 'Truth') 
ax[2].fill_between(freq, f_CI[0], f_CI[2], color = 'darkgrey', alpha = 1, label = '95% CI')
ax[2].tick_params(labelsize=15)
ax[2].set_xlabel(r'$\nu$', fontsize=20, labelpad=10)    
ax[2].set_xlim([0,0.5])
ax[2].set_ylim([0., 1.])
ax[2].grid(True)
ax[2].set_title(r'$\rho^2_{1,2}$', pad=20, fontsize = 20)
plt.tight_layout()
plt.show()



#########################################################
## Simulation Study 2: High-dimensional Analysis ########
import pickle
## simulate data ##################################
n = 640; sigma = 0.5
with open('Data/var_coefs.pkl', 'rb') as handle:
    var_coefs = pickle.load(handle)
Simulation = VarSim.VarSim(var_coefs=var_coefs, n=n, sigma=sigma)
x = Simulation.getData()
freq = np.arange(1,np.floor_divide(1000, 2)+1, 1) / 1000
Spec_mat_true = Simulation.calculateSpecMatrix(freq)

## Model run ############################################
# here to save Demo time, run the first 8 dimensions as a demo.
p=8 # change to 21 if computer is fast enough.
Spec = SpecVI.SpecVI(x[:,:p])
result_list = Spec.runModel(N_delta=30, N_theta=30, lr_map=5e-4, ntrain_map=5e3, sparse_op=False)
spec_mat = result_list[0]

## Result Visualization ###########################
# Reproduce Figure 4
fig = plt.figure(figsize=(10, 6.5), dpi= 60, facecolor='w', edgecolor='k')
#fig.suptitle('Spectral Density Estimates', fontsize='x-large', y=1.05)
fig.subplots_adjust(top=0.95)
for idx in range(8):
    f, Pxx_den0 = signal.periodogram(x[:,idx], fs=1)
    f = f[1:]
    Pxx_den0 = Pxx_den0[1:] / 2
    f_CI = np.abs(spec_mat[...,idx,idx])
    ax = fig.add_subplot(2,4, idx+1)
    ax.plot(f, Pxx_den0, marker = '.', markersize=1, linestyle = 'None')
    ax.plot(freq, np.real(Spec_mat_true[:,idx,idx]), linewidth=2, color = 'red', linestyle="-.", label = 'Truth')
    ax.fill_between(freq, np.squeeze(f_CI[0]), np.squeeze(f_CI[2]),
                    color = 'darkgray', alpha = 1, label = '95% CI')
    #if idx == 0:
    #    ax.legend(fontsize=17, frameon=False)
    ax.set_yscale('log')
    ax.tick_params(labelsize='small')
    ax.set_xlabel(r'$\nu$', fontsize='large')
    ax.set_title(r'$\log f_{%d, %d}$ '%(idx+1, idx+1), fontsize="large", pad=12)
    ax.set_xlim([0, 0.5])
    ax.grid(True)
    #ax.get_yaxis().set_ticks([])
plt.tight_layout()
plt.show()

# Reproduce Figure 5 (if the computer is fast enough to run a total 21-dim analysis)
# =============================================================================
# fig = plt.figure(figsize=(10, 6.5), dpi= 60, facecolor='w', edgecolor='k')
# fig.suptitle('Squared Coherence Estimates (part)', fontsize='x-large', y=1.05)
# fig.subplots_adjust(top=0.95)
# idx = 0
# for ii in [ 8, 9, 10, 15,]:
#     if idx == 8:
#         break
#     for jj in np.arange(ii+1, ii+3):
#         f_CI = np.square(spec_mat[...,ii,jj]) / np.abs(spec_mat[...,ii,ii]) / np.abs(spec_mat[...,jj,jj])
#         ax = fig.add_subplot(2,4, idx+1)
#         ax.plot(freq, np.absolute(Spec_mat_true[:, ii, jj])**2 / (np.real(Spec_mat_true[:,ii,ii] * np.real(Spec_mat_true[:,jj,jj]))) + 7e-3, linestyle='-.', 
#                 color = 'red', linewidth=2, label = 'Truth')
#         ax.fill_between(freq, np.squeeze(f_CI[0])+7e-3, np.squeeze(f_CI[2])+7e-3, 
#                         color = 'darkgrey', alpha = 1, label = '95% CI')
#         #if ii == 0 and jj == 1:
#         #    ax.legend(fontsize=17, frameon=False)
#         ax.tick_params(labelsize='small')
#         ax.set_xlabel(r'$\nu$', fontsize='large')
#         ax.set_xlim([0,0.5])
#         ax.set_ylim([0., 1.])
#         ax.grid(True)
#         ax.set_title(r'$\rho_{%d,%d}^{2}$'%(ii+1,jj+1), fontsize = 'large', pad=12)
#         idx += 1
# plt.tight_layout()
# plt.show()
# =============================================================================
